> **v1.1.0 "Foundation & Safety"**: see [`docs/CHANGELOG.md`](docs/CHANGELOG.md), [`BUILD_GUIDE.md`](BUILD_GUIDE.md) and
> [`docs/TODO.md`](docs/TODO.md) (KNOWN ISSUES). Docs now live in [`docs/`](docs/); the pre-1.1.0 documents are in `docs/legacy/`
> and are partly out of date. The Android layer of this release has not been compiled by its author: run the Quality Gate first.

<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/d2f6e347-874b-4724-bf45-f52325ff5de8

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
